//1. Доработать функцию замены картинки в галерее таким образом, чтобы она проверяла наличие картинки по указанному в src адресу.

var imges = document.querySelectorAll('img');
for (var i = 0; i < imges.length; i++) {
    imges[i].onclick = function (e) {
        var bigImage = document.getElementById('imgBig');
        bigImage.src = e.target.src.replace('small', 'big');

        bigImage.onerror = function () {
            document.querySelector('#err').innerHTML = 'Изображение отсутствует!';
        }
    }
}
