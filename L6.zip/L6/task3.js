//3. *Добавить в галерею функцию перехода к следующему изображению. 
// По сторонам от большой картинки должны быть стрелки «вперед» и «назад», по нажатию на которые происходит замена изображения 
// на следующее или предыдущее.

var forward = document.querySelector('.buttons .next');
var backward = document.querySelector('.buttons .prev');

var imgNum = 0;

function current(i) {
    showImg(imgNum = i);
}

function showImg(i) {
    var items = document.getElementsByClassName("item");
    if (i >= items.length) {
        imgNum = 1;
    }
    if (i < 2) {
        imgNum = items.length - 1;
    }

    for (var item of items) {
        item.style.display = "none";
    }
    items[imgNum - 1].style.display = "block";
}
showImg(imgNum);

forward.onclick = function () {
    showImg(imgNum++);
}

backward.onclick = function () {
    showImg(imgNum--);
}

