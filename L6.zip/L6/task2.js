// 2. Реализовать модуль корзины. Создать блок товаров и блок корзины. 
// У каждого товара есть кнопка «Купить», при нажатии на которую 
// происходит добавление имени и цены товара в блок корзины. 
// Корзина должна уметь считать общую сумму заказа.

var item1 = {
    title: 'Apple',
    imageSrc: "img/small/1.png",
    price: 40,
    count: 1,
};
var item2 = {
    title: 'Cat',
    imageSrc: "img/small/2.png",
    price: 30,
    count: 1,
};
var item3 = {
    title: 'Puzzle',
    imageSrc: "img/small/3.png",
    price: 50,
    count: 1,
};
var item4 = {
    title: 'Button',
    imageSrc: "img/small/4.png",
    price: 70,
    count: 1,
};

var items = [item1, item2, item3, item4];
var summa = 0;

function buy() {
    var assortiment = document.querySelector('.assortiment');
    for (i = 0; i < items.length; i++) {
        var elem = document.createElement('div');
        elem.classList.add('good__item');
        elem.append(document.createTextNode(items[i].title + " " + items[i].price + ' rub'));
        var elemImg = document.createElement('img');
        elemImg.classList.add('img');
        elemImg.src = items[i].imageSrc;
        elem.append(elemImg);
        elemBtn = document.createElement('button');
        elemBtn.innerText = 'Купить';
        elemBtn.classList.add('buyBtn');
        elemBtn.setAttribute('id', 'b' + i);
        elemBtn.onclick = addItems;
        elem.appendChild(elemBtn);
        assortiment.appendChild(elem);
    }
}

function addItems(e) {
    var button = e.target;
    var arrayBtn = button.id;
    var id = arrayBtn[1];
    var chooseItem = items[id];
    var chooseItems = document.querySelector('.chooseItems');

    var tr = chooseItems.insertRow();
    var td = tr.insertCell();

    summa += chooseItem.price;
    td.appendChild(document.createTextNode(chooseItem.title + ' Цена ' + chooseItem.price));
    document.querySelector('.sum').textContent = 'Сумма: ' + summa;
}

buy();
